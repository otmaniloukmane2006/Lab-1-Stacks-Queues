#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int customerNumber;
    struct Node *next;
} Node;

typedef struct Queue {
    Node *front;
    Node *rear;
} Queue;

void initQueue(Queue *q)
{
    q->front = NULL;
    q->rear = NULL;
}

int isEmpty(Queue *q)
{
    return q->front == NULL;
}

void enqueue(Queue *q, int number)
{
    Node *newNode = (Node *)malloc(sizeof(Node));

    if (newNode == NULL)
    {
        printf("Memory allocation error!\n");
        return;
    }

    newNode->customerNumber = number;
    newNode->next = NULL;

    if (isEmpty(q))
    {
        q->front = newNode;
        q->rear = newNode;
    }
    else
    {
        q->rear->next = newNode;
        q->rear = newNode;
    }
}

int dequeue(Queue *q)
{
    Node *temp;
    int number;

    if (isEmpty(q))
    {
        printf("Queue is empty!\n");
        return -1;
    }

    temp = q->front;
    number = temp->customerNumber;
    q->front = q->front->next;

    if (q->front == NULL)
        q->rear = NULL;

    free(temp);

    return number;
}

int peek(Queue *q)
{
    if (isEmpty(q))
        return -1;

    return q->front->customerNumber;
}

void display(Queue *q)
{
    Node *current;

    if (isEmpty(q))
    {
        printf("Queue is empty.\n");
        return;
    }

    current = q->front;

    printf("Queue: ");

    while (current != NULL)
    {
        printf("%d ", current->customerNumber);
        current = current->next;
    }

    printf("\n");
}

int main()
{
    Queue q;
    int choice;
    int number;

    initQueue(&q);

    do
    {
        printf("\n===== BANK QUEUE MENU =====\n");
        printf("1. Enqueue customer\n");
        printf("2. Dequeue customer\n");
        printf("3. Peek\n");
        printf("4. Display queue\n");
        printf("5. Bank queue simulation\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
            case 1:
                printf("Enter customer number: ");
                scanf("%d", &number);
                enqueue(&q, number);
                printf("Customer %d arrived and got a token.\n", number);
                break;

            case 2:
                if (!isEmpty(&q))
                {
                    number = dequeue(&q);
                    printf("Customer %d is being served.\n", number);
                }
                else
                {
                    printf("Queue is empty.\n");
                }
                break;

            case 3:
                if (!isEmpty(&q))
                    printf("Front customer: %d\n", peek(&q));
                else
                    printf("Queue is empty.\n");
                break;

            case 4:
                display(&q);
                break;

            case 5:
                while (!isEmpty(&q))
                    dequeue(&q);

                enqueue(&q, 101);
                printf("Customer 101 arrived and got a token.\n");

                enqueue(&q, 102);
                printf("Customer 102 arrived and got a token.\n");

                number = dequeue(&q);
                printf("Customer %d is being served.\n", number);

                enqueue(&q, 103);
                printf("Customer 103 arrived and got a token.\n");

                number = dequeue(&q);
                printf("Customer %d is being served.\n", number);

                number = dequeue(&q);
                printf("Customer %d is being served.\n", number);

                if (isEmpty(&q))
                    printf("Queue is empty.\n");
                break;

            case 6:
                printf("Exiting...\n");
                break;

            default:
                printf("Invalid choice!\n");
        }

    } while (choice != 6);

    while (!isEmpty(&q))
        dequeue(&q);

    return 0;
}
