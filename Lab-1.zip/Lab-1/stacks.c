#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

typedef struct Node {
    char data;
    struct Node *next;
} Node;

typedef struct Stack {
    Node *top;
} Stack;

void initStack(Stack *s)
{
    s->top = NULL;
}

int isEmpty(Stack *s)
{
    return s->top == NULL;
}

void push(Stack *s, char value)
{
    Node *newNode = (Node *)malloc(sizeof(Node));

    if (newNode == NULL)
    {
        printf("Memory allocation error!\n");
        return;
    }

    newNode->data = value;
    newNode->next = s->top;
    s->top = newNode;
}

char pop(Stack *s)
{
    Node *temp;
    char value;

    if (isEmpty(s))
    {
        printf("Stack is empty!\n");
        return '\0';
    }

    temp = s->top;
    value = temp->data;
    s->top = s->top->next;
    free(temp);

    return value;
}

char peek(Stack *s)
{
    if (isEmpty(s))
        return '\0';

    return s->top->data;
}

void display(Stack *s)
{
    Node *current = s->top;

    if (isEmpty(s))
    {
        printf("Stack is empty.\n");
        return;
    }

    printf("Stack: ");

    while (current != NULL)
    {
        printf("%c ", current->data);
        current = current->next;
    }

    printf("\n");
}

int evaluatePostfix(char expression[])
{
    int stack[100];
    int top = -1;
    int i;
    int operand1, operand2, result;
    char c;

    for (i = 0; expression[i] != '\0'; i++)
    {
        c = expression[i];

        if (c == ' ')
            continue;

        if (isdigit(c))
        {
            stack[++top] = c - '0';
        }
        else if (c == '+' || c == '-' || c == '*' || c == '/')
        {
            if (top < 1)
            {
                printf("Invalid postfix expression!\n");
                return 0;
            }

            operand2 = stack[top--];
            operand1 = stack[top--];

            switch (c)
            {
                case '+':
                    result = operand1 + operand2;
                    break;
                case '-':
                    result = operand1 - operand2;
                    break;
                case '*':
                    result = operand1 * operand2;
                    break;
                case '/':
                    if (operand2 == 0)
                    {
                        printf("Division by zero!\n");
                        return 0;
                    }
                    result = operand1 / operand2;
                    break;
            }

            stack[++top] = result;
        }
    }

    if (top != 0)
    {
        printf("Invalid postfix expression!\n");
        return 0;
    }

    return stack[top];
}

int main()
{
    Stack s;
    int choice;
    char value;
    char expression[100];

    initStack(&s);

    do
    {
        printf("\n===== STACK MENU =====\n");
        printf("1. Push\n");
        printf("2. Pop\n");
        printf("3. Peek\n");
        printf("4. Display\n");
        printf("5. Evaluate Postfix Expression\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
            case 1:
                printf("Enter a character: ");
                scanf(" %c", &value);
                push(&s, value);
                break;

            case 2:
                if (!isEmpty(&s))
                    printf("Popped element: %c\n", pop(&s));
                else
                    printf("Stack is empty!\n");
                break;

            case 3:
                if (!isEmpty(&s))
                    printf("Top element: %c\n", peek(&s));
                else
                    printf("Stack is empty!\n");
                break;

            case 4:
                display(&s);
                break;

            case 5:
                printf("Enter postfix expression: ");
                scanf(" %[^\n]", expression);
                printf("Result = %d\n", evaluatePostfix(expression));
                break;

            case 6:
                printf("Exiting...\n");
                break;

            default:
                printf("Invalid choice!\n");
        }

    } while (choice != 6);

    while (!isEmpty(&s))
        pop(&s);

    return 0;
}
